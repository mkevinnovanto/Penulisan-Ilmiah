# js-mini-projects
This repo contains mini projects built with vanillaJS
